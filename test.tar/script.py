import polars as pl
from cylindra.widgets import CylindraMainWidget
from cylindra import instance


def main(ui: CylindraMainWidget):
    ui.open_image(path='C:\\Users\\liuha\\Desktop\\code\\python\\cylindra\\tests\\14pf_MT.tif', scale=1.052, tilt_range=(-60, 60), bin_size=[1], filter='Lowpass', invert=False, eager=False)
    ui.add_multiscale(bin_size=2)
    ui.set_multiscale(bin_size=1)
    ui.register_path(coords=[[21.97, 123.1, 32.98], [21.97, 83.3, 40.5]], config={'npf_range': (11, 17), 'spacing_range': (3.9, 4.3), 'twist_range': (-0.65, 0.65), 'rise_range': (5.0, 13.0), 'rise_sign': -1, 'clockwise': 'MinusToPlus', 'thickness_inner': 2.8, 'thickness_outer': 2.8, 'fit_depth': 49.0, 'fit_width': 40.0}, err_max=0.5)
    ui.register_path(coords=[[21.97, 83.3, 40.5], [21.97, 123.1, 32.98]], config={'npf_range': (11, 17), 'spacing_range': (3.9, 4.3), 'twist_range': (-0.65, 0.65), 'rise_range': (5.0, 13.0), 'rise_sign': -1, 'clockwise': 'MinusToPlus', 'thickness_inner': 2.8, 'thickness_outer': 2.8, 'fit_depth': 49.0, 'fit_width': 40.0}, err_max=0.5)
    ui.fit_splines(splines='all', max_interval=30, bin_size=1, err_max=1.0, degree_precision=0.5, edge_sigma=2.0, max_shift=5.0)
    ui.refine_splines(splines='all', max_interval=30, err_max=0.8, corr_allowed=0.9, bin_size=1)
    ui.measure_radius(splines='all', bin_size=1, min_radius=1.0, max_radius=100.0)
    ui.local_cft_analysis(splines='all', interval=24.0, depth=50.0, bin_size=1, radius='global', update_glob=False)
    ui.infer_polarity(splines='all', depth=40, bin_size=1)
    ui.global_cft_analysis(splines='all', bin_size=1)
    ui.infer_polarity(splines='all', depth=40, bin_size=1)
    ui.map_monomers(splines='all', orientation=None, offsets=None, radius=None, extensions=(0, 0), prefix='Mole')
    ui.measure_local_radius(splines='all', interval=None, depth=50.0, bin_size=1, min_radius=1.0, max_radius=100.0, update_glob=True)

if __name__ == "__main__":
    ui = instance(create=True)
    main(ui)
